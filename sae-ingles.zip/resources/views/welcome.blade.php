@extends('layouts.app')

@section('title', 'Bienvenido')

@section('section', 'Laratter')

@section('content')

<p>Buenas</p>

@endsection