

<div id="<?php echo e(isset($id) ? $id : 'defaultAlert'); ?>" class="alert alert-<?php echo e(isset($type) ? $type : 'primary'); ?> alert-dismissible fade show <?php echo e(isset($style) ? $style : ''); ?>" role="alert">
  <?php echo e(isset($slot) ? $slot : ''); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>