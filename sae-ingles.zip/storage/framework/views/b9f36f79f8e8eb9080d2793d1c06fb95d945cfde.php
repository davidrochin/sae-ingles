
<span class="badge badge-pill
<?php if($role->name == 'admin'): ?>
badge-dark
<?php elseif($role->name == 'coordinator'): ?>
badge-success
<?php else: ?>
badge-light
<?php endif; ?>
">
<?php echo e($role->description); ?>

</span>