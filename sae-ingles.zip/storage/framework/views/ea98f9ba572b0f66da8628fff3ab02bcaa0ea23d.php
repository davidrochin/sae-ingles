<?php $__env->startSection('title', 'Acerca de'); ?>

<?php $__env->startSection('content'); ?>

<p class="text-center">Desarrollado por</p>

<div class="row">
	<div class="col">
		<img src="https://avatars.githubusercontent.com/davidrochin" class="rounded-circle img-fluid p-4">
		<p class="text-center">José David Rochín Cerecer<br><a href="https://github.com/davidrochin">github/davidrochin</a></p>
	</div>	
	<div class="col">
		<img src="https://avatars.githubusercontent.com/christianLugo5" class="rounded-circle img-fluid p-4">
		<p class="text-center">Christian Ricardo Lugo Arellano<br><a href="https://github.com/christianLugo5">github/christianLugo5</a></p>
	</div>	
</div>

<hr>

<p class="text-center">Hecho con Laravel 5.5, Bootstrap 4 y jQuery.</p>

<div class="text-center">
	<button class="btn btn-primary" onclick="window.history.back();">Volver</button>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>