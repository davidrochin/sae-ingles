<?php $__env->startSection('section', 'Página principal'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.card'); ?>
	<p>Bienvenido(a) <b><?php echo e(Auth::user()->name); ?></b>. Puede navegar por las diferentes secciones del sistema usando el menú de la izquierda.</p>

	<?php $__env->startComponent('components.alert'); ?>
	<?php $__env->slot('type', 'warning'); ?>
	<?php $__env->slot('style', 'mb-0'); ?>
	Si usted no está usando <b>Google Chrome</b>, puede que este sistema no funcione correctamente. Para asegurarse de que este sistema funcione como debería, descargue la última versión de Google Chrome haciendo clic <a href="https://www.google.com.mx/chrome/" target="_blank">aquí</a>.
	<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>