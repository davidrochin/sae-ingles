<?php if(session()->get('success')): ?>
	<?php $__env->startComponent('components.alert'); ?>
		<?php $__env->slot('message', session()->get('success')); ?>
		<?php $__env->slot('type', 'success'); ?>
	<?php echo $__env->renderComponent(); ?>
<?php endif; ?>