
<span class="badge 
<?php if($role->name == 'admin'): ?>
badge-dark
<?php elseif($role->name == 'coordinator'): ?>
badge-success
<?php else: ?>
badge-light
<?php endif; ?>
">
<?php echo e($role->description); ?>

</span>