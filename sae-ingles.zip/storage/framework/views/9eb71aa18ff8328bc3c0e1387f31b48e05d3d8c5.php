<?php $__env->startSection('title', 'Usuarios del sistema'); ?>
<?php $__env->startSection('section', 'Usuarios del sistema'); ?>

<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('tables.users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">
    <div class="mx-auto">
        <?php echo e($users->appends($_GET)->links('pagination::bootstrap-4')); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>