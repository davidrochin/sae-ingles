<?php $__env->startSection('title', 'Iniciar sesión'); ?>

<?php $__env->startSection('content'); ?>
<form class="form" method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo e(csrf_field()); ?>


    <!-- Email input -->
    <div class="form-group">
        <label for="email" >Correo electrónico</label>
        <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('email')): ?> <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div> <?php endif; ?>
    </div>

    <!-- Password input -->
    <div class="form-group">
        <label for="password">Contraseña</label>
        <input id="password" type="password" name="password" required class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('password')): ?> <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div> <?php endif; ?>
    </div>

    <div class="form-group">
        <div class="checkbox">
            <label>
                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Recordarme
            </label>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Iniciar sesión</button>
    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">¿Olvidaste tu contraseña?</a>
        
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>