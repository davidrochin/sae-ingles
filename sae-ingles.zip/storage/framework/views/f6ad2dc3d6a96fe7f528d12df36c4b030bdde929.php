<div class="card <?php echo e(isset($class) ? $class : ''); ?> border-<?php echo e(isset($border) ? $border : 'default'); ?>" style="width: <?php echo e(isset($width) ? $width : ''); ?>px;">

    <?php if(isset($header)): ?>
    <div class="card-header"><?php echo e($header); ?></div>
    <?php endif; ?>

    <div class="card-body">
        <?php echo e(isset($slot) ? $slot : ''); ?>

    </div>

    <?php if(isset($footer)): ?>
    <div class="card-footer">
        <?php echo e($footer); ?>

    </div>
    <?php endif; ?>
</div>