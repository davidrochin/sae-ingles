<?php $__env->startSection('section', 'Información del grupo'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-xl">

		
		<?php $__env->startComponent('components.card'); ?>
			<?php $__env->slot('header', 'Información básica'); ?>
			<?php $__env->slot('class', 'mb-4'); ?>
			
			<form action="<?php echo e(route('groups')); ?>/editar" method="post" name="editGroupForm">
				<div class="form-row">
					<div class="col">
						<?php $__env->startComponent('components.form-input'); ?>
						<?php $__env->slot('tag', 'Nombre'); ?>
						<?php $__env->slot('name', 'name'); ?>
						<?php $__env->slot('disabled', 'true'); ?>
						<?php $__env->slot('class', 'bg-white'); ?>
						<?php $__env->slot('value', $group->name); ?>
						<?php echo $__env->renderComponent(); ?>
					</div>
					<div class="col">
						<?php $__env->startComponent('components.form-input'); ?>
						<?php $__env->slot('tag', 'Código'); ?>
						<?php $__env->slot('name', 'code'); ?>
						<?php $__env->slot('disabled', 'true'); ?>
						<?php $__env->slot('class', 'bg-white'); ?>
						<?php $__env->slot('value', $group->code); ?>
						<?php echo $__env->renderComponent(); ?>
					</div>
					<div class="col">
						<?php $__env->startComponent('components.form-input'); ?>
						<?php $__env->slot('tag', 'Nivel'); ?>
						<?php $__env->slot('name', 'level'); ?>
						<?php $__env->slot('disabled', 'true'); ?>
						<?php $__env->slot('class', 'bg-white'); ?>
						<?php $__env->slot('value', $group->level); ?>
						<?php echo $__env->renderComponent(); ?>
					</div>
				</div>

				<div class="form-row">
					<div class="col">
						<div class="form-group">
							<label for="periodControlInput">Periodo</label>
							<select class="form-control bg-white" id="periodControlInput" name="periodId" disabled>
								<?php $__currentLoopData = App\Period::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($period->id); ?>" <?php echo e($group->period->id == $period->id ? 'selected' : ''); ?>><?php echo e($period->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>
					<div class="col">
						<?php $__env->startComponent('components.form-input'); ?>
						<?php $__env->slot('tag', 'Año'); ?>
						<?php $__env->slot('name', 'year'); ?>
						<?php $__env->slot('disabled', 'true'); ?>
						<?php $__env->slot('class', 'bg-white'); ?>
						<?php $__env->slot('value', $group->year); ?>
						<?php echo $__env->renderComponent(); ?>
					</div>
				</div>

				<div class="form-group">
					<label for="professorControlInput">Profesor</label>
					<select class="form-control bg-white" id="professorControlInput" name="professorId" disabled>
						<?php $__currentLoopData = $professors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($professor->id); ?>" <?php echo e($group->user->id == $professor->id ? 'selected' : ''); ?>><?php echo e($professor->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>

				<div class="form-row">
					<div class="col">
						<?php $__env->startComponent('components.form-input'); ?>
						<?php $__env->slot('tag', 'Hora de inicio'); ?>
						<?php $__env->slot('name', 'scheduleStart'); ?>
						<?php $__env->slot('disabled', 'true'); ?>
						<?php $__env->slot('type', 'time'); ?>
						<?php $__env->slot('class', 'bg-white'); ?>
						<?php $__env->slot('value', $group->schedule_start); ?>
						<?php echo $__env->renderComponent(); ?>
					</div>
					<div class="col">
						<?php $__env->startComponent('components.form-input'); ?>
						<?php $__env->slot('tag', 'Hora de fin'); ?>
						<?php $__env->slot('name', 'scheduleEnd'); ?>
						<?php $__env->slot('disabled', 'true'); ?>
						<?php $__env->slot('type', 'time'); ?>
						<?php $__env->slot('class', 'bg-white'); ?>
						<?php $__env->slot('value', $group->schedule_end); ?>
						<?php echo $__env->renderComponent(); ?>
					</div>
				</div>

				<div class="form-group">
					<label for="mondayCheckbox">Días de la semana</label>
					<div class="card" style="<?php echo e($errors->has('days') ? 'border-color: red;' : ''); ?>">
						<div class="card-body">
							<?php $__env->startComponent('components.days-checkboxes'); ?>
							<?php $__env->slot('group', $group); ?>
							<?php $__env->slot('disabled', 'true'); ?>
							<?php echo $__env->renderComponent(); ?>
						</div>
					</div>
					<div style=" color: #dc3545; font-size: 80%; margin-top: .25rem;"><?php echo e($errors->first('days')); ?></div>
				</div>
				<input type="submit" id="submitFormButton" class="btn btn-primary float-right" value="Aplicar cambios" hidden>
			</form>

		<?php echo $__env->renderComponent(); ?>

		
		<?php $__env->startComponent('components.card'); ?>
			<?php $__env->slot('header', 'Acciones'); ?>
			<?php $__env->slot('class', 'mb-3'); ?>

			<div class="form-row">
				<div class="col-auto"><button class="btn btn-danger">Eliminar grupo</button></div>
				<!--<div class="col-auto"><button class="btn btn-danger">Vaciar grupo</button></div>-->
				<div class="col-auto"><button id="editGroupButton" class="btn btn-secondary" onclick="formEditMode('editGroupForm'); deleteById('editGroupButton');">Editar grupo</button></div>
				<div class="col-auto"><a class="btn btn-secondary" href="<?php echo e(route('attendanceLists', $group->id)); ?>" target="_blank">Imprimir lista de asistencia</a></div>
			</div>
		<?php echo $__env->renderComponent(); ?>
		
	</div>
		
	<div class="col">

		
		<?php $__env->startComponent('components.card'); ?>
			<?php $__env->slot('header', 'Agregar alumnos al grupo'); ?>
			<?php $__env->slot('class', 'mb-4'); ?>

			
			<form action="/grupos/agregar" method="post">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="groupId" value="<?php echo e($group->id); ?>">
				<div class="input-group mb-3">
				  <input id="studentAddInput" type="text" class="form-control" name="studentId" placeholder="Escriba el ID de un alumno para agregarlo a este grupo..." autocomplete="off">
				  <div class="input-group-append">
				    <button class="btn btn-outline-secondary" type="submit">Agregar</button>
				  </div>
				</div>
			</form>

			<p class="text-center">Si usted presiona agregar, se agregará a <span id="studentToAdd" class="font-weight-bold">...</span> a este grupo.</p>
		<?php echo $__env->renderComponent(); ?>

		
		<?php $__env->startComponent('components.card'); ?>
			<?php $__env->slot('header', 'Alumnos del grupo'); ?>
			<?php $__env->slot('class', 'mb-3'); ?>

			
			<?php $__env->startComponent('components.group-students'); ?>
				<?php $__env->slot('group', $group); ?>
			<?php echo $__env->renderComponent(); ?>
		<?php echo $__env->renderComponent(); ?>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">

	//Este script es para hacer la búsqueda en vivo del nombre del alumno,
	//deacuerdo al ID escrito en el input para agregar nuevos alumnos.
	$('#studentAddInput').on('input',function(){

		//Obtener el valor del input
		$value=$(this).val();

		//Si no hay valor, establecerlo como un -1 para no obtener una URL indeseada
		if(!$value){ $value = -1; }

		//Iniciar la petición con AJAX
		$.ajax({
			type : 'get',
			url : '<?php echo e(route('students')); ?>/' + $value,
			data:{ 'json':1, },

			//Poner el nombre del alumno en el span
			success:function(data){ $('#studentToAdd').html(data['last_names'] + ' ' + data['first_names']); },
			error:function(data){ $('#studentToAdd').html('...'); }
		});
	})


</script>

<script type="text/javascript">

	$.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['background' => 'gray'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>