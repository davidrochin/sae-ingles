    <table class="table table-hover">
        <thead class="thead-light">
            <tr>
                <!--<th></th>-->
                <th>ID</th>
                <th>Número de control</th>
                <th>Nombre(s)</th>
                <th>Apellido(s)</th>
                <th>Carrera</th>
                <th>Teléfono</th>
                <th>Correo electrónico</th>
                <th></th>
            </tr>
        </thead>

        <!--Imprimir un renglón dentro de la tabla para cada estudiante-->
        <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="studentRow<?php echo e($student->id); ?>" class="clickable-row">
                <!--<td><input type="checkbox" name="studentCheckbox<?php echo e($student->id); ?>" onchange="selectStudent(<?php echo e($student->id); ?>)"></td>-->
                <td><?php echo e($student->id); ?></td>
                <td><?php echo e($student->control_number); ?></td>
                <td><?php echo e($student->first_names); ?></td>
                <td><?php echo e($student->last_names); ?></td>
                <td><?php echo e($student->career->short_name); ?></td>
                <td><?php echo e($student->phone_number); ?></td>
                <td><?php echo e($student->email); ?></td>
                <td><a href="<?php echo e(route('students')); ?>/<?php echo e($student->id); ?>">Ver alumno</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>