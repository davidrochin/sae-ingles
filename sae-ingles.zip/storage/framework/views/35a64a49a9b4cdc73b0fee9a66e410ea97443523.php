    <table class="table table-hover">

        <thead class="thead-light">
            <tr>
                <!--<th></th>-->
                <th>ID</th>
                <th>Profesor</th>
                <th>Horario</th>
                <th>Dias</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>Nivel</th>
                <th></th>
            </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="tableRow<?php echo e($group->id); ?>" class="clickable-row">
                <td><?php echo e($group->id); ?></td>
                <td><?php echo e($group->user->name); ?></td>
                <td><?php echo e($group->schedule_start); ?> - <?php echo e($group->schedule_end); ?></td>
                <td>
                    <?php $__env->startComponent('components.days-badges'); ?>
                        <?php $__env->slot('days', $group->days); ?>
                    <?php echo $__env->renderComponent(); ?>
                </td>
                <td><?php echo e($group->code); ?></td>
                <td><?php echo e($group->name); ?></td>
                <td><?php echo e($group->level); ?></td>
                <td><a href="<?php echo e(route('groups')); ?>/<?php echo e($group->id); ?>">Ver grupo</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>