<?php $__env->startSection('title', 'No se encuentra'); ?>

<?php $__env->startSection('content'); ?>

<p>La página a la cual ha tratado de ingresar no se ha encontrado en el sistema. Si cree que esto es un error, por favor comuníqueselo a un administrador.</p>
<button class="btn btn-primary float-right" onclick="window.history.back();">Volver atrás</button>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>