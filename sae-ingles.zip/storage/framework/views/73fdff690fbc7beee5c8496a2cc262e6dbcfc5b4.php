<?php $__env->startSection('title', 'Lista de asistencia'); ?>
<?php $__env->startSection('content'); ?>

<div class="row mb-5 mt-2 text-center">
	<div class="col">
		<h4>Formato oficial de listas de asistencia</h4>
		<h4>Departamento de Gestión Tecnológica y Vinculación</h4>
		<h4>Programa CLE-ITLM</h4>
	</div>
</div>

<table class="table table-bordered text-nowrap table-attendance">
	<tbody>
		<td>Nivel <b><?php echo e($group->level); ?></b></td>
		<td>Horario de <b><?php echo e($group->schedule_start); ?> - <?php echo e($group->schedule_end); ?></b></td>
		<td>Profesor <b><?php echo e($group->user->name); ?></b></td>
		<td>Aula <b><?php echo e(2); ?></b></td>
		<td>Periodo <b><?php echo e($group->period->name); ?></b></td>
	</tbody>
</table>

<table class="table table-bordered table-attendance text-nowrap">
	<thead>
		<th>No.</th>
		<th>Nombre completo</th>
		<th>No. control</th>
		<th>Carrera</th>
		<?php for($i = 0 ; $i < $attendanceSlots ; $i++): ?>
			<th></th>
		<?php endfor; ?>
	</thead>
	<tbody>
		<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($key + 1); ?></td>
				<td><?php echo e($student->last_names); ?> <?php echo e($student->first_names); ?></td>
				<td><?php echo e($student->control_number); ?></td>
				<td><?php echo e($student->career->short_name); ?></td>
				<?php for($i = 0 ; $i < $attendanceSlots ; $i++): ?>
					<th></th>
				<?php endfor; ?>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">

	//Abrir el documento en modo de impresión
	$(document).ready( function(){
		window.print();
	});
</script>

<style type="text/css">
	.table-attendance th {
		font-size: 1.2rem;
	}
	.table-attendance td {
		padding-bottom: 0.3rem;
		padding-top: 0.3rem;
		font-size: 1.2rem;
	}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blank', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>