<?php $__env->startSection('title', 'Bienvenido'); ?>

<?php $__env->startSection('content'); ?>

<div class="jumbotron text-center">
    <h1>Bienvenido</h1>

    <nav>
        <ul class="nav nav-pills">
            <li class="nav-link">Alumnos</li>
            <li class="nav-link">Profesores</li>
            <li class="nav-link">Clases</li>
        </ul>
    </nav>
</div>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-6">
            <img class="img-thumbnail" src="<?php echo e($message['image']); ?>">
            <p class="card-text"><?php echo e($message['content']); ?> - <a href="/messages/<?php echo e($message['id']); ?>">Leer más...</a></p>
            
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No hay mensajes</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>