<div class="form-group">
	<label for="groupNameControlInput">Nombre del Grupo</label>
	<input type="text" id="groupNameControlInput" name="groupName" class="form-control <?php echo e($errors->has('groupName') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('firstNames')); ?>">
	<div class="invalid-feedback"><?php echo e($errors->first('groupName')); ?></div>
</div>