<?php $__env->startSection('title', 'Usuarios del sistema'); ?>
<?php $__env->startSection('section', 'Usuarios del sistema'); ?>

<?php $__env->startSection('content'); ?>

<div class="">

	<!--Modal-->
	<?php $__env->startComponent('components.modal'); ?>
		<?php $__env->slot('id', 'newUserModal'); ?>
		<?php $__env->slot('title', 'Nuevo usuario'); ?>
		<?php $__env->slot('dismiss', 'Cancelar'); ?>

		<?php $__env->slot('body'); ?>

			<!-- Formulario de nuevo grupo -->
			<form class="form" action="/usuarios/crear" method="post" id="createUserForm">

				<?php echo e(csrf_field()); ?>


				<div class="form-row">
					<div class="col">
						<?php $__env->startComponent('components.form-input'); ?>
							<?php $__env->slot('tag', 'Nombre'); ?>
							<?php $__env->slot('name', 'name'); ?>
						<?php echo $__env->renderComponent(); ?>
					</div>	
				</div>				
				<div class="form-group">
					<label for="roleId">Carrera</label>
                        <select name="roleId" class="form-control">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->description); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
				</div>
				<div class="form-row">
					<div class="col">
						<?php $__env->startComponent('components.form-input'); ?>
							<?php $__env->slot('tag', 'Correo electrónico'); ?>
							<?php $__env->slot('name', 'email'); ?>
						<?php echo $__env->renderComponent(); ?>
					</div>
				</div>
				<div class="form-row">
					<div class="col">
						<?php $__env->startComponent('components.form-input'); ?>
							<?php $__env->slot('tag', 'Contraseña'); ?>
							<?php $__env->slot('name', 'password'); ?>
							<?php $__env->slot('type', 'password'); ?>
						<?php echo $__env->renderComponent(); ?>
					</div>
				</div>

			</form>
		<?php $__env->endSlot(); ?>

		<?php $__env->slot('footer'); ?>
			<input type="submit" class="btn btn-primary" value="Crear" form="createUserForm">
		<?php $__env->endSlot(); ?>
	<?php echo $__env->renderComponent(); ?>

	<!--Botones para manipular tabla y buscador-->
	<div class="btn-toolbar mb-3 w-100" role="toolbar" aria-label="Toolbar with button groups">
		<div class="btn-group" role="group" aria-label="First group">
			<button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#newUserModal">Nuevo</button>
		</div>
	</div>

</div>

<div class="">
	
	
</div>

	<?php echo $__env->make('tables.users', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
    <div class="mx-auto">
        <?php echo e($users->appends($_GET)->links('pagination::bootstrap-4')); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>