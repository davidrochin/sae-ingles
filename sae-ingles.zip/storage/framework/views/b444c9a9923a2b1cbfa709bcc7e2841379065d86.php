<div class="form-group">
	<label for="<?php echo e($name); ?>ControlInput"><?php echo e($tag); ?></label>
	<input type="<?php echo e(isset($type) ? $type : 'text'); ?>" id="<?php echo e($name); ?>ControlInput" name="<?php echo e($name); ?>" class="form-control <?php echo e($errors->has($name) ? 'is-invalid' : ''); ?> <?php echo e(isset($class) ? $class : ''); ?>" value="<?php echo e(isset($value) ? $value : ''); ?>" <?php echo e(isset($disabled) ? 'disabled' : ''); ?>>
	<div class="invalid-feedback"><?php echo e($errors->first($name)); ?></div>
</div>