<?php if(session()->get('success')): ?>
	<?php $__env->startComponent('components.alert'); ?>
		<?php $__env->slot('type', 'success'); ?>

		<?php echo e(session()->get('success')); ?>


	<?php echo $__env->renderComponent(); ?>
<?php endif; ?>