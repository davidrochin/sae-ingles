    <table class="table table-hover">

        <thead class="thead-light">
            <tr>
                <!--<th></th>-->
                <th>ID</th>
                <th>Rol</th>
                <th>Nombre</th>
                <th>Correo electrónico</th>
                <th>Contraseña</th>
                <th></th>
            </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="tableRow<?php echo e($user->id); ?>" class="clickable-row">
                <td><?php echo e($user->id); ?></td>
                <td>
                    <?php $__env->startComponent('components.role-badge', ['role' => $user->role]); ?>
                    <?php echo $__env->renderComponent(); ?>
                </td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <?php if($user->role->name == 'professor'): ?>
                        <a href="#">Nueva contraseña</a>
                    <?php else: ?>
                        
                    <?php endif; ?>
                </td>
                <td><a href="<?php echo e(route('users')); ?>/<?php echo e($user->id); ?>">Ver usuario</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>