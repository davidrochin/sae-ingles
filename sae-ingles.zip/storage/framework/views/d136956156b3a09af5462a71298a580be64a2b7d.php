

<div class="alert alert-<?php echo e(isset($type) ? $type : 'primary'); ?> alert-dismissible fade show" role="alert">
  <?php echo e(isset($message) ? $message : ''); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>