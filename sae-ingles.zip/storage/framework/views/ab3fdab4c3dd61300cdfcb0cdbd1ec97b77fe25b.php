
<!doctype html>
<html lang="en" class="bg-<?php echo e(isset($background) ? $background : ''); ?>">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>
      <?php echo $__env->yieldContent('title', config('app.name', 'ERROR')); ?>
    </title>
    
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(URL::asset('css/dashboard.css')); ?>" rel="stylesheet">

    <!-- Hola de estilos propia para hacer ajustes -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap-adjustments.css')); ?>" />
  </head>

  <body>

    <!-- Modal default. Para usar este modal mande un mensaje en la variable $modalMessage -->
    <?php $__env->startComponent('components.modal'); ?>
      <?php $__env->slot('id', 'defaultModal'); ?>
      <?php $__env->slot('title', 'Mensaje del sistema'); ?>
      <?php $__env->slot('body'); ?>
        <?php echo e(session('message')); ?>

      <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">

      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="<?php echo e(route('home')); ?>"><?php echo e(config('app.name', 'ERROR')); ?></a>
      <div class="form-control form-control-dark text-light text-center w-100">Autenticado como <?php echo e(Auth::user()->name); ?> - <?php echo e(Auth::user()->role->description); ?></div>

      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Cerrar sesión</a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo e(csrf_field()); ?></form>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">

        <!--Barra de navegación lateral-->
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">

            <?php if(Auth::user()->hasAnyRole(['admin', 'coordinator'])): ?> 

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Coordinación</span>
            </h6>

            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link <?php echo e(isset($parentRoute) && $parentRoute == 'students' ? 'active' : ''); ?>" href="<?php echo e(route('students')); ?>">
                  <span data-feather="users"></span>
                  Alumnos
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e(isset($parentRoute) && $parentRoute == 'groups' ? 'active' : ''); ?>" href="<?php echo e(route('groups')); ?>">
                  <span data-feather="calendar"></span>
                  Grupos
                </a>
              </li>
            </ul>

            <?php endif; ?>

            <?php if(Auth::user()->hasAnyRole(['admin','coordinator'])): ?> 

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Sistema</span>
            </h6>

            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link <?php echo e(isset($parentRoute) && $parentRoute == 'users' ? 'active' : ''); ?>" href="<?php echo e(route('users')); ?>">
                  <span data-feather="users"></span>
                  Usuarios
                </a>
              </li>
            </ul>

            <?php endif; ?>

             

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Para profesores</span>
            </h6>

            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('grades')); ?>">
                  <span data-feather="users"></span>
                  Mis grupos
                </a>
              </li>
            </ul>

            

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Información</span>
            </h6>

            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link <?php echo e(isset($parentRoute) && $parentRoute == 'about' ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>">
                  <span data-feather="tag"></span>
                  Acerca de
                </a>
              </li>
            </ul>

          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4 bg-<?php echo e(isset($background) ? $background : ''); ?>">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2 <?php echo e(isset($background) && ($background == 'dark' || $background == 'secondary') ? 'text-white' : ''); ?><?php echo e(isset($background) && $background == 'gray' ? 'text-secondary' : ''); ?>">
              <?php echo $__env->yieldContent('section', 'Sección desconocida'); ?>
            </h1>
            <!--<div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                <button class="btn btn-sm btn-outline-secondary">Share</button>
                <button class="btn btn-sm btn-outline-secondary">Export</button>
              </div>
              <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                Semanal
              </button>
            </div>-->
          </div>

          <!-- Alerta de éxito. Solo se muestra si es necesario -->
          <?php echo $__env->make('components.success-alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php echo $__env->yieldContent('content', 'No hay contenido que mostrar...'); ?>

        </main>
      </div>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>-->
    <!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>-->
    <!--<script>window.jQuery || document.write('<script src="../../../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>-->

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    <!-- jQuery -->
    
    <script src="<?php echo e(URL::asset('js/jquery-3.3.1.min.js')); ?>" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="<?php echo e(URL::asset('js/sae.js')); ?>"></script>

  </body>

  <?php echo $__env->yieldContent('scripts'); ?>

  <!-- Abrir el modal que muestra mensajes del sistema si es necesario -->
  <?php if(session('message')): ?>
  <script type="text/javascript">
    $( document ).ready(function() {
          $('#defaultModal').modal('show');
      });
  </script>
  <?php endif; ?>

</html>