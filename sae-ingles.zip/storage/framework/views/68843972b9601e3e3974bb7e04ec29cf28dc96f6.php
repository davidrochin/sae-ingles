<?php $__env->startSection('title', 'Alumnos'); ?>
<?php $__env->startSection('section', 'Alumnos'); ?>

<?php $__env->startSection('content'); ?>

<div class="">

    <!-- Modal para agregar un estudiante -->
    <?php $__env->startComponent('components.modal'); ?>
        <?php $__env->slot('id', 'newStudentModal'); ?>
        <?php $__env->slot('title', 'Nuevo estudiante'); ?>
        <?php $__env->slot('dismiss', 'Cancelar'); ?>
        
        <?php $__env->slot('body'); ?>

            <!-- Formulario de nuevo alumno -->
            <form class="form" action="/alumnos/crear" method="post" id="createStudentForm">

                <!-- Crear el token de seguridad -->
                <?php echo e(csrf_field()); ?>


                <div class="form-row">
                    <div class="col">
                        <?php $__env->startComponent('components.form-input'); ?>
                            <?php $__env->slot('tag', 'Número de control'); ?>
                            <?php $__env->slot('name', 'controlNumber'); ?>
                         <?php echo $__env->renderComponent(); ?>
                    </div>
                    <div class="col-8">
                        <div class="form-group">
                            <label for="careerControlInput">Carrera</label>
                            <select class="form-control" id="careerControlInput" name="careerId">
                                <!-- Llenar el select con las carreras de la base de datos -->
                                <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($career->id); ?>" <?php echo e(old('careerId') == $career->id ? 'selected' : ''); ?>><?php echo e($career->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>

                <?php $__env->startComponent('components.form-input'); ?>
                    <?php $__env->slot('tag', 'Nombre(s)'); ?>
                    <?php $__env->slot('name', 'firstNames'); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('components.form-input'); ?>
                    <?php $__env->slot('tag', 'Apellidos'); ?>
                    <?php $__env->slot('name', 'lastNames'); ?>
                <?php echo $__env->renderComponent(); ?>

                <div class="form-row">
                    <div class="col">
                        <?php $__env->startComponent('components.form-input'); ?>
                            <?php $__env->slot('tag', 'Teléfono'); ?>
                            <?php $__env->slot('name', 'phoneNumber'); ?>
                            <?php $__env->slot('type', 'tel'); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                    <div class="col-7">
                        <?php $__env->startComponent('components.form-input'); ?>
                            <?php $__env->slot('tag', 'Correo electrónico'); ?>
                            <?php $__env->slot('name', 'email'); ?>
                            <?php $__env->slot('type', 'email'); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </form>
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('footer'); ?>
            <input type="submit" class="btn btn-primary" value="Crear" form="createStudentForm">
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <!--Botones para manipular tabla de estudiantes y buscador-->
    <div class="btn-toolbar mb-3 w-100" role="toolbar" aria-label="Toolbar with button groups">
        <div class="btn-group" role="group" aria-label="First group">
            <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#newStudentModal">Nuevo</button>
        </div>

        <!-- Formulario para buscar -->
        <form class="form col-auto mr-0 ml-auto" action="/alumnos/" method="get">
            <div class="input-group ">
                <input type="text" class="form-control w-auto" placeholder="Escriba algo..." value="<?php echo e(app('request')->input('keyword')); ?>" aria-describedby="btnGroupAddon" name="keyword">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-outline-secondary" type="button">Buscar</button>
                </div>
            </div>
        </form>
    </div>

</div>

<div class="">

    <!-- Tabla de estudiantes -->
    <?php echo $__env->make('tables.students', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Botones de paginación -->
    <div class="row">
        <div class="mx-auto">
            <?php echo e($students->appends($_GET)->links('pagination::bootstrap-4')); ?>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">

    var selectedId;

    //Método para que cuando un renglón de la tabla esté seleccionado este cambie de color
    function selectStudent(id) {
        var row = document.getElementById("studentRow" + id);
        var chk = document.getElementsByName("studentCheckbox" + id);
        if (chk[0].checked) {

            row.className = "table-active";

            //console.log(row);

            //Obtener las otras rows y deseleccionarlas
            if(selectedId != null){
                var previousRow = document.getElementById("studentRow" + selectedId);
                var previousChk = document.getElementsByName("studentCheckbox" + selectedId);
                previousRow.className = "";
                previousChk[0].checked = false;
            }

            //Establecer el ID como el seleccionado actual
            selectedId = id;
            document.forms['deleteStudentForm'].elements[0].value = selectedId;

        } else {
            row.className = "";
            selectedId = null;
            document.forms['deleteStudentForm'].elements[0].value = null;
        }

    }

</script>

<!-- Si hubo un error en el formulario de nuevo estudiante, abrir modal automaticamente -->
<?php if($errors->any()): ?>
    <script type="text/javascript">
        var $errorMessage = '';
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            $errorMessage = $errorMessage + ' <?php echo e($error); ?>';
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        //alert($errorMessage);
        
        //Abrir modal de estudiante
        $( document ).ready(function() {
            $('#newStudentModal').modal('show');
        });
        
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>