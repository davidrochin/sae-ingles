<?php $__env->startSection('title', 'No tiene permisos'); ?>

<?php $__env->startSection('content'); ?>

<p>Usted no tiene privilegios para ver/hacer esto. Si cree que esto es un error, por favor comuníquese con un administrador del sistema.</p>
<p class="text-danger"><?php echo e(isset($permissionMessage) ? $permissionMessage : ''); ?></p>
<a class="btn btn-primary float-right" role="button" href="<?php echo e(route('home')); ?>">Página principal</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>