<table class="table table-hover table-bordered">

	<thead class=>
		<tr>
			<th>No.</th>
			<th>Nombre</th>
			<th>No. control</th>
			<th>Acciones</th>
		</tr>
	</thead>

	<tbody>
		<?php $__empty_1 = true; $__currentLoopData = $group->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<tr>
			<td><?php echo e($key + 1); ?></td>
			<td><a href="<?php echo e(route('students')); ?>/<?php echo e($student->id); ?>"><?php echo e($student->last_names); ?> <?php echo e($student->first_names); ?></a></td>
			<td><?php echo e(isset($student->control_number) ? $student->control_number : 'Alumno externo'); ?></td>
			<form action="/grupos/remover" method="post" id="removeForm<?php echo e($student->id); ?>">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="studentId" value="<?php echo e($student->id); ?>"><input type="hidden" name="groupId" value="<?php echo e($group->id); ?>">
				<td><a class="badge badge-danger" href="javascript:;" onclick=" document.getElementById('removeForm<?php echo e($student->id); ?>').submit();">Remover</a></td>
			</form>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<tr>
			<td colspan="99" class="text-center text-muted">No hay alumnos asignados a este grupo.</td>
		</tr>
		<?php endif; ?>
	</tbody>

</table>