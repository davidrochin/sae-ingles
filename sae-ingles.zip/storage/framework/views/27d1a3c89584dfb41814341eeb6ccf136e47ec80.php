<div class="form-group">
	<label for="<?php echo e($controlInput); ?>"><?php echo e($tag); ?></label>
	<input type="text" id="<?php echo e($controlInput); ?>" name="<?php echo e($name); ?>" class="form-control <?php echo e($errors->has($name) ? 'is-invalid' : ''); ?>" value="<?php echo e(old($name)); ?>">
	<div class="invalid-feedback"><?php echo e($errors->first($name)); ?></div>
</div>