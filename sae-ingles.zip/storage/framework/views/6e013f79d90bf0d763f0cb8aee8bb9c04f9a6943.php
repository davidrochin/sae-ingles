



<?php if(strpos($days, '1') !== false): ?>
Lun
<?php endif; ?>

<?php if(strpos($days, '2') !== false): ?>
Mar
<?php endif; ?>

<?php if(strpos($days, '3') !== false): ?>
Mie
<?php endif; ?>

<?php if(strpos($days, '4') !== false): ?>
Jue
<?php endif; ?>

<?php if(strpos($days, '5') !== false): ?>
Vie
<?php endif; ?>

<?php if(strpos($days, '6') !== false): ?>
Sab
<?php endif; ?>

<?php if(strpos($days, '7') !== false): ?>
Dom
<?php endif; ?>