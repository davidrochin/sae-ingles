<table class="table table-hover table-bordered">

	<?php if(!isset($hideHead)): ?>
	<thead>
		<tr>
			<th>Nombre</th>
			<th>Horario</th>
			<th>Profesor</th>
			<th>Estado</th>
			<th></th>
		</tr>
	</thead>
	<?php endif; ?>

	<tbody>
		<?php $__empty_1 = true; $__currentLoopData = $student->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<tr>
			<td><?php echo e($group->name); ?></td>
			<td><?php echo e(Carbon\Carbon::parse($group->schedule_start)->format('g:i A')); ?> - <?php echo e(Carbon\Carbon::parse($group->schedule_end)->format('g:i A')); ?></td>
			<td><?php echo e($group->user->name); ?></td>
			<td>
				<?php $__env->startComponent('components.group-state-badge', ['group' => $group]); ?>
				<?php echo $__env->renderComponent(); ?>
			</td>
			<td><a href="<?php echo e(route('groups')); ?>/<?php echo e($group->id); ?>">Ver más</a></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<?php endif; ?>
	</tbody>

</table>