<?php $__env->startSection('title', 'Registar usuario'); ?>

<?php $__env->startSection('content'); ?>
<form class="form" method="post" action="<?php echo e(route('register')); ?>">
    <?php echo e(csrf_field()); ?>


    <div class="form-group">
        <label for="name">Name</label>
        <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('name')): ?> 
        <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div> 
        <?php endif; ?>
    </div>

    <div class="form-group">
        <label for="email">Correo electrónico</label>
        <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('email')): ?> 
        <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
        <?php endif; ?>
    </div>

    <div class="form-group">
        <label for="password">Contraseña</label>
        <input id="password" type="password" name="password" value="<?php echo e(old('password')); ?>" required class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('password')): ?> 
        <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div> 
        <?php endif; ?>
    </div>

    <div class="form-group">
        <label for="password-confirm">Confirmar contraseña</label>
        <input id="password-confirm" type="password" name="password_confirmation" required class="form-control">
    </div>

    <button type="submit" class="btn btn-primary">Registrar</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>