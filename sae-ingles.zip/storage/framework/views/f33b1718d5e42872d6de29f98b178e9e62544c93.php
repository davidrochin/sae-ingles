<?php $__env->startSection('title', 'Alumno '.$student->id); ?>
<?php $__env->startSection('section', 'Información del alumno'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl">

        <!-- Tarjeta de información básica -->
        <?php $__env->startComponent('components.card'); ?>
            <?php $__env->slot('header', 'Información del alumno'); ?>

            <form class="form" action="/alumnos/modificar" method="post" name="editStudentForm">

                    <?php echo e(csrf_field()); ?>


                    <div class="form-row">
                        <div class="col">
                             <?php $__env->startComponent('components.form-input'); ?>
                                <?php $__env->slot('tag', 'ID'); ?>
                                <?php $__env->slot('name', 'id'); ?>
                                <?php $__env->slot('disabled', 'true'); ?>
                                <?php $__env->slot('class', 'bg-white'); ?>
                                <?php $__env->slot('value', $student->id); ?>
                            <?php echo $__env->renderComponent(); ?>
                        </div>
                        <div class="col">
                            <?php $__env->startComponent('components.form-input'); ?>
                                <?php $__env->slot('tag', 'Número de control'); ?>
                                <?php $__env->slot('name', 'controlNumber'); ?>
                                <?php $__env->slot('disabled', 'true'); ?>
                                <?php $__env->slot('class', 'bg-white'); ?>
                                <?php $__env->slot('value', $student->control_number); ?>
                            <?php echo $__env->renderComponent(); ?>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="col">
                            <?php $__env->startComponent('components.form-input'); ?>
                                <?php $__env->slot('tag', 'Nombre(s)'); ?>
                                <?php $__env->slot('name', 'firstNames'); ?>
                                <?php $__env->slot('disabled', 'true'); ?>
                                <?php $__env->slot('class', 'bg-white'); ?>
                                <?php $__env->slot('value', $student->first_names); ?>
                            <?php echo $__env->renderComponent(); ?>
                        </div>
                        <div class="col">
                            <?php $__env->startComponent('components.form-input'); ?>
                                <?php $__env->slot('tag', 'Apellidos'); ?>
                                <?php $__env->slot('name', 'lastNames'); ?>
                                <?php $__env->slot('disabled', 'true'); ?>
                                <?php $__env->slot('class', 'bg-white'); ?>
                                <?php $__env->slot('value', $student->last_names); ?>
                            <?php echo $__env->renderComponent(); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="careerId">Carrera</label>
                        <select name="careerId" class="form-control bg-white" disabled>
                            <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($student->career_id == $career->id ? 'selected' : ''); ?> value="<?php echo e($career->id); ?>"><?php echo e($career->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <?php $__env->startComponent('components.form-input'); ?>
                        <?php $__env->slot('tag', 'Teléfono'); ?>
                        <?php $__env->slot('name', 'phoneNumber'); ?>
                        <?php $__env->slot('disabled', 'true'); ?>
                        <?php $__env->slot('class', 'bg-white'); ?>
                        <?php $__env->slot('value', $student->phone_number); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form-input'); ?>
                        <?php $__env->slot('tag', 'Correo electrónico'); ?>
                        <?php $__env->slot('name', 'email'); ?>
                        <?php $__env->slot('disabled', 'true'); ?>
                        <?php $__env->slot('class', 'bg-white'); ?>
                        <?php $__env->slot('value', $student->email); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <input type="submit" class="btn btn-primary float-right" id="sendFormButton" value="Aplicar cambios" hidden>
                </form>
        <?php echo $__env->renderComponent(); ?>

        <!-- Tarjeta de acciones -->
        <?php $__env->startComponent('components.card'); ?>
            <?php $__env->slot('header', 'Acciones'); ?>
            <?php $__env->slot('class', 'mt-3'); ?>

            <div class="form-row">
                <div class="col-auto">
                    <form action="/alumnos/eliminar" method="post" name="deleteStudentForm">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($student->id); ?>">
                        <button type="submit" class="btn btn-danger">Eliminar alumno</button>
                    </form>
                </div>
                <div class="col-auto">
                    <button id="editStudentButton" class="btn btn-secondary" onclick="formEditMode('editStudentForm'); deleteById('editStudentButton')">Modificar datos</button>
                </div>
            </div>
        <?php echo $__env->renderComponent(); ?>

    </div>

    <div class="col-7">
        
        <?php $__env->startComponent('components.card'); ?>
            <?php $__env->slot('header', 'Grupos a los que pertenece el alumno'); ?>

            <?php $__env->startComponent('components.student-groups'); ?>
                <?php $__env->slot('student', $student); ?>
            <?php echo $__env->renderComponent(); ?>

        <?php echo $__env->renderComponent(); ?>

    </div>
</div>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    
    //Activa todos los elementos de la Form
    function formEditMode(formName){

        //Activar los elementos de la Form
        var formElements = document.forms[formName].elements;
        for(var i = 0; i < formElements.length; i++){
            if(formElements[i].name != 'id'){
                formElements[i].readOnly = false;
                formElements[i].disabled = false;
            }
        }

        //Aparecer el botón de enviar
        document.getElementById('sendFormButton').hidden = false;
    }

    //Elimina un elemento por su id
    function deleteById(id){
        var element = document.getElementById(id);
        element.outerHTML = '';
        delete element;
    }

    <?php if($errors->any()): ?>
    alert('<?php echo e($errors->all()[0]); ?>');
    <?php endif; ?>

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['background' => 'gray'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>